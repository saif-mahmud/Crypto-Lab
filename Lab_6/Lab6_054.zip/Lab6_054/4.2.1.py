print "saif"+"\x00"*4+"A+"
